export {default as MovieInformation} from './MovieInformation';
